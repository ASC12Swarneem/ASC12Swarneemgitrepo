import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/App.module';
 
platformBrowserDynamic().bootstrapModule(AppModule);