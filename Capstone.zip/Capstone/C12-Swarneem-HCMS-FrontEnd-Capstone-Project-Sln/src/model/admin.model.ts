export class Admin{
    firstName!: string;
    lastName!: string;
    email!: string;
    phoneNo!: string;
    password!: string;
    confirmPassword!: string;
}