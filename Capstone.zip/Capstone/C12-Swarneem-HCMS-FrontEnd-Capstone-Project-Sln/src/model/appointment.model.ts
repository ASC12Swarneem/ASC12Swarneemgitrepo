export class Appointment {
  id?: string;
  patientName?: string;
  patientAge?: number;
  patientWeight?: number;
  patientCity?: string;
  department?: string;
  doctor?: string;
  appointmentDate?: Date; 
}
