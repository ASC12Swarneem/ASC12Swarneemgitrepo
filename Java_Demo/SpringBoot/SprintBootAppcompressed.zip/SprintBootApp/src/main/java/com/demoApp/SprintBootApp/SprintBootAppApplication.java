package com.demoApp.SprintBootApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintBootAppApplication.class, args);
	}

}
