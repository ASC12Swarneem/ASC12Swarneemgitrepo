package com.demoApp.SprintBootApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
